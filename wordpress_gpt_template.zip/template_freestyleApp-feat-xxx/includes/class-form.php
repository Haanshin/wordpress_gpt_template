<?php
class Form
{
    private $fields = array();
    private $appearance = array();
    private $file_uploads_enabled = false;

    /**
     * Add a form field.
     *
     * @param string $name The name of the field.
     * @param string $type The type of the field (e.g., text, email, textarea).
     * @param array $options Additional options for the field (e.g., label, required).
     */
    public function add_field($name, $type, $options = array())
    {
        // Add the field to the fields array.
        $field = array(
            'name' => $name,
            'type' => $type,
            'options' => $options
        );
        $this->fields[] = $field;
    }

    /**
     * Customize the form appearance.
     *
     * @param array $appearance The appearance options for the form (e.g., background color, font size).
     */
    public function customize_appearance($appearance)
    {
        // Customize the form appearance.
        $this->appearance = $appearance;
    }

    /**
     * Enable file uploads in the form.
     */
    public function enable_file_uploads()
    {
        $this->file_uploads_enabled = true;
    }

    /**
     * Validate the form data.
     *
     * @param array $data The form data to validate.
     *
     * @return bool True if the data is valid, false otherwise.
     */
    public function validate_data($data)
    {
        // Validate the form data.
        foreach ($this->fields as $field) {
            $name = $field['name'];
            $type = $field['type'];
            $options = $field['options'];

            // Perform validation based on field type and options.
            switch ($type) {
                case 'text':
                    // Validate text field.
                    if (isset($data[$name]) && $options['required'] && empty($data[$name])) {
                        return false;
                    }
                    break;
                case 'email':
                    // Validate email field.
                    if (isset($data[$name]) && $options['required'] && !filter_var($data[$name], FILTER_VALIDATE_EMAIL)) {
                        return false;
                    }
                    break;
                case 'textarea':
                    // Validate textarea field.
                    if (isset($data[$name]) && $options['required'] && empty($data[$name])) {
                        return false;
                    }
                    break;
                // Add more cases for other field types if needed.
            }
        }

        return true;
    }
}
