<?php
/**
 * Plugin Name: Free Demo Form Mail
 * Plugin URI: https://example.com
 * Description: WordPress form mail plugin that allows users to create and customize forms on their website.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL2
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

// Include the main plugin class.
require_once plugin_dir_path(__FILE__) . 'includes/class-free-demo-form-mail.php';

// Initialize the plugin.
function free_demo_form_mail_init()
{
    $plugin = new Free_Demo_Form_Mail();
    $plugin->init();
}
add_action('plugins_loaded', 'free_demo_form_mail_init');
