<?php
class Free_Demo_Form_Mail
{
    /**
     * Initialize the plugin.
     */
    public function init()
    {
        // Register the form settings page.
        add_action('admin_menu', array($this, 'register_settings_page'));

        // Enqueue necessary scripts and styles.
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // Handle form submission.
        add_action('admin_post_free_demo_form_mail_submit', array($this, 'handle_form_submission'));
    }

    /**
     * Register the form settings page.
     */
    public function register_settings_page()
    {
        add_menu_page(
            'Free Demo Form Mail',
            'Form Mail',
            'manage_options',
            'free-demo-form-mail',
            array($this, 'render_settings_page'),
            'dashicons-email-alt'
        );
    }

    /**
     * Enqueue necessary scripts and styles.
     */
    public function enqueue_scripts()
    {
        // Enqueue scripts and styles here.
        wp_enqueue_script('demo-form-scripts', 'path/to/demo-form-scripts.js', array('jquery'), '1.0', true);
        wp_enqueue_style('demo-form-styles', 'path/to/demo-form-styles.css');
    }

    /**
     * Render the form settings page.
     */
    public function render_settings_page()
    {
        // Render the form settings page here.
        ?>
        <div class="wrap">
            <h1>Free Demo Form Mail Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('free_demo_form_mail_settings');
                do_settings_sections('free-demo-form-mail');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Handle form submission.
     */
    public function handle_form_submission()
    {
        // Handle form submission here.
        if (isset($_POST['submit'])) {
            // Process form data and send email
            $name = sanitize_text_field($_POST['name']);
            $email = sanitize_email($_POST['email']);
            $message = sanitize_textarea_field($_POST['message']);

            // Send email
            $to = 'admin@example.com';
            $subject = 'Free Demo Form Submission';
            $body = "Name: $name\n\nEmail: $email\n\nMessage: $message";
            $headers = array('Content-Type: text/html; charset=UTF-8');

            wp_mail($to, $subject, $body, $headers);

            // Redirect back to the form page
            wp_redirect(admin_url('admin.php?page=free-demo-form-mail'));
            exit;
        }
    }
}

// Create an instance of the class and initialize the plugin
$free_demo_form_mail = new Free_Demo_Form_Mail();
$free_demo_form_mail->init();
