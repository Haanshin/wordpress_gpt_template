<?php
class Email_Notification
{
    private $to;
    private $subject;
    private $headers;

    /**
     * Set the recipient email address.
     *
     * @param string $to The recipient email address.
     */
    public function set_recipient($to)
    {
        $this->to = $to;
    }

    /**
     * Set the email subject.
     *
     * @param string $subject The email subject.
     */
    public function set_subject($subject)
    {
        $this->subject = $subject;
    }

    /**
     * Set the email headers.
     *
     * @param string $headers The email headers.
     */
    public function set_headers($headers)
    {
        $this->headers = $headers;
    }

    /**
     * Send the email notification.
     *
     * @param array $data The form data to include in the email.
     *
     * @return bool True if the email was sent successfully, false otherwise.
     */
    public function send_notification($data)
    {
        $message = $this->build_message($data);
        return mail($this->to, $this->subject, $message, $this->headers);
    }

    /**
     * Build the email message.
     *
     * @param array $data The form data to include in the email.
     *
     * @return string The email message.
     */
    private function build_message($data)
    {
        $message = '';
        foreach ($data as $key => $value) {
            $message .= $key . ': ' . $value . "\n";
        }
        return $message;
    }
}
