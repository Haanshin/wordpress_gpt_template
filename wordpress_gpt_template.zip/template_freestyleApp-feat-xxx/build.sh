#!/bin/bash

echo "Please complete the compilation script ./build.sh"
