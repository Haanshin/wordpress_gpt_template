<?php
class File_Upload
{
    private $allowed_types = array();
    private $max_size = 0;
    private $upload_dir;

    /**
     * Set the allowed file types.
     *
     * @param array $allowed_types The allowed file types.
     */
    public function set_allowed_types($allowed_types)
    {
        $this->allowed_types = $allowed_types;
    }

    /**
     * Set the maximum file size.
     *
     * @param int $max_size The maximum file size in bytes.
     */
    public function set_max_size($max_size)
    {
        $this->max_size = $max_size;
    }

    /**
     * Set the upload directory.
     *
     * @param string $upload_dir The upload directory.
     */
    public function set_upload_dir($upload_dir)
    {
        $this->upload_dir = $upload_dir;
    }

    /**
     * Validate the uploaded file.
     *
     * @param array $file The uploaded file data.
     *
     * @return bool True if the file is valid, false otherwise.
     */
    public function validate_file($file)
    {
        $file_type = $file['type'];
        $file_size = $file['size'];

        // Check if the file type is allowed
        if (!in_array($file_type, $this->allowed_types)) {
            return false;
        }

        // Check if the file size is within the maximum limit
        if ($file_size > $this->max_size) {
            return false;
        }

        return true;
    }

    /**
     * Move the uploaded file to the designated directory.
     *
     * @param array $file The uploaded file data.
     *
     * @return bool True if the file was moved successfully, false otherwise.
     */
    public function move_uploaded_file($file)
    {
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];

        // Generate a unique file name to avoid conflicts
        $unique_file_name = uniqid() . '_' . $file_name;

        // Move the uploaded file to the designated directory
        if (move_uploaded_file($file_tmp, $this->upload_dir . '/' . $unique_file_name)) {
            return true;
        }

        return false;
    }
}
